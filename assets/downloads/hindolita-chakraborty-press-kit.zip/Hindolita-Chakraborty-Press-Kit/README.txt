HINDOLITA CHAKRABORTY - PRESS KIT
Vocalist and Educator
https://raginibyhindolita.com/

Contents
  Hindolita-Chakraborty-Bio.pdf           Biography
  photos/                                 Photographs for press and event promotion

These photographs may be used to publicise Hindolita Chakraborty's performances,
classes and related coverage. Please do not crop her face or alter the images.

Contact
  Email      raaginimusical@gmail.com
  Phone      +91 70135 01324
  Address    Gajularamaram, Hyderabad
  Classes    Kondapur, Gachibowli, Gajularamaram, Kukatpally (Hyderabad)
  Instagram  @raaginibyhindolita
  Facebook   facebook.com/hindolita.chakraborty
